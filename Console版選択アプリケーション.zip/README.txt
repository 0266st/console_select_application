このアプリはレジストリを使用していないのでインストール、アンインストールともにファイルを削除、必要なフォルダに配置するだけで済みます。
内容：
このファイル(README.txt)
Console版選択アプリケーション.exe
これのみ。
ほい。
https://github.com/aonoshito/console_select_application/